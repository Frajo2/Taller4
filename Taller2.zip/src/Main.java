import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.LinkedList;
import java.util.Queue;

public class Main extends JFrame {

    private JTextField customerNameField;
    private JButton addButton, processButton;
    private JTextArea queueArea, attendedArea;
    private Queue<String> customerQueue;

    public Main() {
        setTitle("Simulación de Fila en el Banco");
        setSize(500, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        customerQueue = new LinkedList<>();

        // Panel for adding customers
        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new FlowLayout());

        JLabel nameLabel = new JLabel("Nombre del Cliente:");
        customerNameField = new JTextField(20);
        addButton = new JButton("Agregar Cliente");

        inputPanel.add(nameLabel);
        inputPanel.add(customerNameField);
        inputPanel.add(addButton);

        // Panel for queue and attended customers
        JPanel displayPanel = new JPanel();
        displayPanel.setLayout(new GridLayout(2, 1));

        queueArea = new JTextArea();
        queueArea.setEditable(false);
        queueArea.setBorder(BorderFactory.createTitledBorder("Clientes en la Fila"));

        attendedArea = new JTextArea();
        attendedArea.setEditable(false);
        attendedArea.setBorder(BorderFactory.createTitledBorder("Clientes Atendidos"));

        displayPanel.add(new JScrollPane(queueArea));
        displayPanel.add(new JScrollPane(attendedArea));

        // Button to process next customer
        processButton = new JButton("Atender Siguiente Cliente");

        // Add components to the frame
        setLayout(new BorderLayout());
        add(inputPanel, BorderLayout.NORTH);
        add(displayPanel, BorderLayout.CENTER);
        add(processButton, BorderLayout.SOUTH);

        // Action listeners
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String name = customerNameField.getText().trim();
                if (!name.isEmpty()) {
                    customerQueue.add(name);
                    updateQueueDisplay();
                    customerNameField.setText("");
                } else {
                    JOptionPane.showMessageDialog(null, "Por favor, ingrese el nombre del cliente.");
                }
            }
        });

        processButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (!customerQueue.isEmpty()) {
                    String name = customerQueue.poll();
                    String message = name + " ha sido " + (isFemale(name) ? "atendida." : "atendido.");
                    attendedArea.append(message + "\n");
                    updateQueueDisplay();
                } else {
                    JOptionPane.showMessageDialog(null, "No hay clientes en la fila.");
                }
            }
        });
    }

    private void updateQueueDisplay() {
        queueArea.setText("");
        for (String name : customerQueue) {
            queueArea.append(name + "\n");
        }
    }

    private boolean isFemale(String name) {
        // Simple check: if the name ends with 'a' or 'A', assume female
        if (name.endsWith("a") || name.endsWith("A")) {
            return true;
        }
        return false;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Main simulation = new Main();
            simulation.setVisible(true);
        });
    }
}
