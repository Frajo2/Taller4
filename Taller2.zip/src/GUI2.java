import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.LinkedList;
import java.util.Queue;

public class GUI2 extends JFrame {

    private JTextField customerNameField;
    private JButton addButton, processButton;
    private JTextArea queueArea, attendedArea;
    private Queue<String> customerQueue;

    public GUI2() {
        setTitle("Gestión de Fila en el Banco");
        setSize(500, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        customerQueue = new LinkedList<>();

        // Panel para agregar clientes
        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new FlowLayout());

        JLabel nameLabel = new JLabel("Nombre del Cliente:");
        customerNameField = new JTextField(20);
        addButton = new JButton("Agregar Cliente");

        inputPanel.add(nameLabel);
        inputPanel.add(customerNameField);
        inputPanel.add(addButton);

        // Panel para mostrar la cola y los clientes atendidos
        JPanel displayPanel = new JPanel();
        displayPanel.setLayout(new GridLayout(2, 1));

        queueArea = new JTextArea();
        queueArea.setEditable(false);
        queueArea.setBorder(BorderFactory.createTitledBorder("Clientes en la Fila"));

        attendedArea = new JTextArea();
        attendedArea.setEditable(false);
        attendedArea.setBorder(BorderFactory.createTitledBorder("Clientes Atendidos"));

        displayPanel.add(new JScrollPane(queueArea));
        displayPanel.add(new JScrollPane(attendedArea));

        // Botón para atender al siguiente cliente
        processButton = new JButton("Atender Siguiente Cliente");

        // Añadir componentes al frame
        setLayout(new BorderLayout());
        add(inputPanel, BorderLayout.NORTH);
        add(displayPanel, BorderLayout.CENTER);
        add(processButton, BorderLayout.SOUTH);

        // Listeners para los botones
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String name = customerNameField.getText().trim();
                if (!name.isEmpty()) {
                    customerQueue.add(name);
                    updateQueueDisplay();
                    customerNameField.setText("");
                } else {
                    JOptionPane.showMessageDialog(null, "Por favor, ingrese el nombre del cliente.");
                }
            }
        });

        processButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (!customerQueue.isEmpty()) {
                    String name = customerQueue.poll();
                    String message = name + " ha sido " + (isFemale(name) ? "atendida." : "atendido.");
                    attendedArea.append(message + "\n");
                    updateQueueDisplay();
                } else {
                    JOptionPane.showMessageDialog(null, "No hay clientes en la fila.");
                }
            }
        });
    }

    private void updateQueueDisplay() {
        queueArea.setText("");
        for (String name : customerQueue) {
            queueArea.append(name + "\n");
        }
    }

    private boolean isFemale(String name) {
        // Si el nombre termina con 'a' o 'A', asumimos que es femenino
        if (name.endsWith("a") || name.endsWith("A")) {
            return true;
        }
        return false;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            GUI2 gui = new GUI2();
            gui.setVisible(true);
        });
    }
}

