import javax.swing.*;

public class ColaPrioridad {
    public Nodo frente;

    public ColaPrioridad() {
        frente = null;
    }

    // Método para añadir (agregar de acuerdo a prioridad) un paciente
    public void añadir(String nombre, int prioridad) {
        Nodo nuevoNodo = new Nodo(nombre, prioridad);
        if (estaVacia() || prioridad < frente.prioridad) {
            // Insertar al frente si la cola está vacía o si tiene mayor prioridad
            nuevoNodo.siguiente = frente;
            frente = nuevoNodo;
        } else {
            // Buscar el lugar correcto para insertar según la prioridad
            Nodo actual = frente;
            while (actual.siguiente != null && actual.siguiente.prioridad <= prioridad) {
                actual = actual.siguiente;
            }
            nuevoNodo.siguiente = actual.siguiente;
            actual.siguiente = nuevoNodo;
        }
    }


    public String mostrar(JTextArea textArea) {
        if (estaVacia()) {
            textArea.setText("La cola está vacía.");
            return null;
        }
        String mensajeAtendido = frente.dato + " ha sido atendido (prioridad " + frente.prioridad + ").";
        frente = frente.siguiente;
        textArea.append(mensajeAtendido + "\n"); // Añadir al JTextArea en vez de sobrescribir
        return mensajeAtendido;
    }

    // Método para verificar si la cola está vacía
    public boolean estaVacia() {
        return frente == null;
    }


}
